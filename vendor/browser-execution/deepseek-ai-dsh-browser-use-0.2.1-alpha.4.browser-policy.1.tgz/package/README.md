---
description: "Browser-use provider registration for deployments that enable one browser backend at a time."
kind: "package-reference"
---

# @deepseek-ai/dsh-browser-use

English | [中文](README.zh.md)

## Summary

A deployment can enable one browser-use provider at a time. Loading another provider fails with the registered provider name. Each provider supplies its own tools and owns browser sessions. This package adds no model-visible tools or browser operations.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Further Exploration](#further-exploration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

-----

<a id="use-this-package"></a>
## Use this package

Mount the service once beside the chosen provider in a Cordis composition:

```yaml
- name: '@deepseek-ai/dsh-browser-use'
```

The service has no configuration. Provider plugins inject `browserUse` and call `ctx.browserUse.register(BrowserUseProviderName(name))`; the brand is exported from `@deepseek-ai/dsh-browser-use/brand`. The returned effect disposer releases that registration.

Providers stop admitting tool calls, close their resources, and await owned work before releasing the registration. `ctx.browserUse.providerName` reports the registered name until release.

<a id="execution-requests"></a>
### Execution requests

The pure `@deepseek-ai/dsh-browser-use/execution` export resolves one operation-local request. JavaScript and CLI JSON consumers first call `parseBrowserExecutionRequest`; typed consumers call `resolveBrowserExecution` directly. Each request supplies `scope.sessionId`, `scope.taskId` (a browser task-batch identity, not an Agent Teams task), `purpose`, `ownership`, and required `capabilities`. `mode` is explicit or defaults to `headless` for `automation`, `capture`, and `web-regression`, `headed` for `interactive`, and `native` for `desktop-regression`. Filesystem permissions never select or relax browser mode.

Capabilities include `dom`, `screenshot`, `browser-extension`, `native-window`, `isolated-context`, `isolated-download-directory`, and `authenticated-state`. `owned-process` permits the owning adapter to close its browser; `borrowed-connection` permits only connection cleanup; `task-lease` requires `resourceOwnerId` and permits releasing only the task's leased pages, contexts, and download resources, never killing the browser owner.

Adapters call `validateBrowserCapabilities` before acquisition and `validateBrowserExecution` with the final backend arguments immediately before launch or attachment. True headless requires a resolver-selected `chromium-headless-shell`, matching executable path, and no channel override; contradictory headless flags and extension arguments fail. A GUI Chromium with `headless: true` does not satisfy this request. Browser borrowed connections and task leases use `target.kind: attach` in explicit `headed` mode. Electron desktop execution uses `target.kind: native` with an `electron` engine and `native` mode; a persistent externally owned application uses `task-lease` plus `resourceOwnerId`, not `owned-process` or a borrowed CDP connection. Unsupported capabilities fail with `BrowserExecutionError.code` rather than silently switching mode.

The adapter independently verifies its installed package name/version, browser revision/version, and actual binary. For a task lease, `target.resourceOwnerId` comes from the actual browser/application broker, never by echoing the request; startup rejects a missing or different broker owner. Engine descriptors are resolver reports, not verification credentials: this pure module does not inspect executable files or authenticate arbitrary JSON engine claims. Its single compiled ESM subpath has no runtime imports and can be packaged for fresh-process consumers. The native Stagehand managed launcher consumes these checks at its actual startup; no global last-request state exists.

<a id="local-browser-policy-artifact"></a>
### Local browser-policy artifact

The source manifest records `dshLocalArtifactVersion: 0.2.1-alpha.4.browser-policy.1`. The off-cycle local `file:` artifact reads that source value into its actual npm `version` and sets `private: true`; consumers verify the installed version, source SHA, tarball integrity, and lockfile. Its unmodified peer closure retains the verified baseline versions. This is not an official DSH-family publication or a full `release:verify` result. The workspace's standard shared version stays `0.2.1-alpha.4`, and the installed desktop App/ASAR version is unchanged. The optional native Stagehand source declares the same local revision; this artifact neither installs nor activates that adapter.

<a id="headless-engine"></a>
### Pinned headless engine

`@deepseek-ai/dsh-browser-use/headless-engine` exports `resolvePinnedHeadlessEngine({ pin, playwrightPackageRoot, overrideName, env?, cwd?, executablePath? })`. The trusted adapter supplies a reviewed, complete SHA-256 inventory and an absolute package root. A Python Playwright driver's bundled `playwright-core` package can use the same resolver. The pin records package/browser versions, revision, native layout, platform, architecture, and the supported Darwin minimum; local measurements are not upstream signatures. Pin content and package root are not tool/request fields.

Resolution checks the actual system, installed package/manifest, canonical shell path, native arm64 Mach-O header, executable permissions, completion marker, active installer lock, every pinned resource's real bytes, and actual `--version` output. It currently verifies macOS arm64 only. It rejects GUI `.app` paths and symlink targets, tampered/partial installations, platform overrides, and resources escaping their installation. Explicit `executablePath` takes precedence over the environment but receives identical checks; invalid explicit values never fall back. Relative cache/override paths use the operation's absolute `cwd`, not `INIT_CWD`. `PLAYWRIGHT_BROWSERS_PATH=0`, empty/unset values, and npm environment precedence retain Playwright semantics. No newer-cache search occurs.

The immutable result includes `kind: chromium-headless-shell`, resolver identity, canonical executable, package/browser versions, revision, binary SHA-256, and `dom`, `screenshot`, `isolated-context`, and `isolated-download-directory` capability descriptors. Pass that actual result to `validateBrowserExecution` immediately before launch. The backend still creates and cleans up those isolated resources; this resolver does not launch a browser or implement resource leasing. It advertises neither native windows, extensions, nor authenticated account state. Failures expose `HeadlessEngineError.code: HEADLESS_BROWSER_UNAVAILABLE` and retain the real cause, without GUI fallback. Production options cannot replace system identity, hashing, or the version probe with test functions.

-----

<a id="understand-the-implementation"></a>
## Understand the implementation

<details>
<summary>Implementation internals — click to expand</summary>

One private name owns the slot. Cordis effects remove contributions when their plugin unloads; a repeated disposer cannot remove a later registration. The [source](src/index.ts) contains no browser object, operation interface, resource lifecycle, or provider selector.

</details>

-----

<a id="further-exploration"></a>
## Further Exploration

- [Browser use](../../../docs/subsystems/browser-use.md) — provider selection and Session ownership.
- [Playwright MCP provider](../../experimental/browser-use-playwright-mcp/README.md) — Playwright browser tools.
- [Chrome DevTools MCP provider](../../experimental/browser-use-chrome-devtools-mcp/README.md) — Chromium inspection and control.
- [Stagehand provider](../../experimental/browser-use-stagehand-native/README.md) — native browser operations with AI assistance.

-----

<a id="model-experience"></a>
## Model Experience

None, as this registry only records provider names.

#### KV Cache effect

Registration does not alter model requests. Provider-owned tools and guidance determine their own request-prefix effects.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>

The service limits registrations within its Cordis service instance.

- **Browser ownership** — providers own browser resources and enforce Session isolation; this service stores no browser state.
- **Provider selection** — configuration selects the provider; the model cannot switch registered backends at runtime.
- **Execution coverage** — execution requests affect only adapters that explicitly consume the API. Arbitrary shell/Python scripts and MCP launchers are not intercepted. Resolver identity checks and task-lease/context/download cleanup belong to the adapter; declaring a capability does not implement it.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

None.

</details>
