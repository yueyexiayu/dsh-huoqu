---
description: "浏览器操作 提供方 注册服务，供一次启用一个浏览器后端的部署使用。"
kind: "package-reference"
---

# @deepseek-ai/dsh-browser-use

[English](README.md) | 中文

## 概述

部署可以一次启用一个浏览器操作 提供方。加载另一个 提供方 时会报错并指出已注册的 提供方 名称。各 提供方 提供自己的工具并拥有浏览器会话。本包不添加模型可见工具或浏览器操作。

## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [延伸阅读](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延期工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

在 Cordis 组合中，将服务与所选 提供方 一起挂载一次：

```yaml
- name: '@deepseek-ai/dsh-browser-use'
```

服务没有配置。提供方 插件注入 `browserUse` 并调用 `ctx.browserUse.register(BrowserUseProviderName(name))`；品牌类型从 `@deepseek-ai/dsh-browser-use/brand` 导出。返回的 effect 清理器释放该注册。

提供方 在释放注册前停止接收工具调用、关闭资源并等待自己拥有的工作结束。`ctx.browserUse.providerName` 在释放之前持续报告已注册名称。

<a id="execution-requests"></a>
### 执行请求

纯模块 `@deepseek-ai/dsh-browser-use/execution` 解析单次操作的请求。JavaScript 和 CLI JSON 调用方先调用 `parseBrowserExecutionRequest`；已类型化的调用方直接调用 `resolveBrowserExecution`。每个请求显式提供 `scope.sessionId`、`scope.taskId`（浏览器任务批次标识，不是 Agent Teams 任务）、`purpose`、`ownership` 和必需的 `capabilities`。`mode` 可显式指定；`automation`、`capture` 和 `web-regression` 默认 `headless`，`interactive` 默认 `headed`，`desktop-regression` 默认 `native`。文件权限不会选择或放宽浏览器模式。

能力包括 `dom`、`screenshot`、`browser-extension`、`native-window`、`isolated-context`、`isolated-download-directory` 和 `authenticated-state`。`owned-process` 允许所属适配器关闭浏览器；`borrowed-connection` 只允许清理连接；`task-lease` 必须提供 `resourceOwnerId`，只能释放该任务租用的页面、context 和下载资源，不能终止浏览器所有者。

适配器在获取资源前调用 `validateBrowserCapabilities`，并在实际启动或连接前，将最终后端参数交给 `validateBrowserExecution`。真正无头要求 resolver 选中的 `chromium-headless-shell`、一致的可执行路径且没有 channel 覆盖；矛盾的 headless 标志和扩展参数会失败。GUI Chromium 配合 `headless: true` 不满足该请求。浏览器借用连接和任务租约通过 `target.kind: attach` 以显式 `headed` 模式连接。Electron 桌面执行使用 `target.kind: native`、`electron` 引擎和 `native` 模式；外部拥有的持久应用使用 `task-lease` 加 `resourceOwnerId`，不伪称 `owned-process` 或借用 CDP 连接。不支持的能力通过 `BrowserExecutionError.code` 失败，不静默切换模式。

适配器独立核验实际安装的包名及版本、浏览器 revision 及版本、实际二进制。任务租约的 `target.resourceOwnerId` 必须来自真实浏览器或应用 broker，不能原样复制请求；broker owner 缺失或不同都会拒绝启动。engine 描述是 resolver 报告，不是验证凭据：纯模块不会检查可执行文件，也不会认证任意 JSON 的 engine 声明。编译后的单 ESM 子路径没有运行时 import，可打包给独立新进程消费。原生 Stagehand 的 managed 启动入口实际使用这些检查；没有全局最近请求状态。

<a id="local-browser-policy-artifact"></a>
### 本地浏览器策略产物

源码 manifest 记录 `dshLocalArtifactVersion: 0.2.1-alpha.4.browser-policy.1`。独立于正式发布周期的本地 `file:` 产物从该源码字段读取真实 npm `version`，并设置 `private: true`；消费者核对实际安装版本、源码 SHA、tgz 完整性及 lockfile。未修改的 peer 闭包保留已验证的基线版本。这不是官方 DSH 发布族的发布，也不代表完整 `release:verify` 通过。工作区标准统一版本保持 `0.2.1-alpha.4`，已安装桌面 App/ASAR 的版本不变。可选原生 Stagehand 源码声明相同本地修订；此产物不安装或激活该适配器。

<a id="headless-engine"></a>
### 固定版本无头引擎

`@deepseek-ai/dsh-browser-use/headless-engine` 导出 `resolvePinnedHeadlessEngine({ pin, playwrightPackageRoot, overrideName, env?, cwd?, executablePath? })`。受信任适配器提供经过审查的完整 SHA-256 清单和绝对包根路径。Python Playwright driver 内置的 `playwright-core` 包也能使用同一解析器。pin 记录包与浏览器版本、revision、原生目录布局、平台、架构和支持的 Darwin 最低版本；本地测量不是上游签名。pin 内容和包根路径不属于工具或请求参数。

解析过程核验真实系统、安装包与 manifest、规范化 shell 路径、原生 arm64 Mach-O 头、可执行权限、安装完成标志、正在使用的安装锁、每项固定资源的实际字节和真实 `--version` 输出。目前只验证 macOS arm64。GUI `.app` 路径及符号链接目标、篡改或不完整安装、平台覆盖和逃逸安装目录的资源都会被拒绝。显式 `executablePath` 优先于环境变量，但接受相同完整检查；显式非法值绝不回退。相对 cache 或 override 路径使用单次操作的绝对 `cwd`，不使用 `INIT_CWD`。`PLAYWRIGHT_BROWSERS_PATH=0`、空值或未设置和 npm 环境变量优先级保持 Playwright 语义。不扫描较新的 cache 版本。

不可变结果包含 `kind: chromium-headless-shell`、resolver 身份、规范化可执行路径、包与浏览器版本、revision、二进制 SHA-256，以及 `dom`、`screenshot`、`isolated-context` 和 `isolated-download-directory` 能力描述。在实际启动前，把该真实结果交给 `validateBrowserExecution`。后端仍负责创建及清理这些隔离资源；解析器不启动浏览器，也不实现资源租约。它不宣称原生窗口、扩展或已认证账户状态。失败提供 `HeadlessEngineError.code: HEADLESS_BROWSER_UNAVAILABLE` 并保留实际 cause，不回退 GUI。生产参数不能用测试函数替代系统身份、哈希或版本探测。

-----

<a id="understand-the-implementation"></a>
## 理解实现

<details>
<summary>实现内部机制 — 点击展开</summary>

一个私有名称拥有该注册位。Cordis effect 在插件卸载时移除贡献；重复调用清理器不能移除后续注册。[源码](src/index.ts) 不包含浏览器对象、操作接口、资源生命周期或 提供方 选择器。

</details>

-----

<a id="further-exploration"></a>
## 延伸阅读

- [浏览器操作](../../../docs/subsystems/browser-use.zh.md) — 提供方 选择与 Session 所有权。
- [Playwright MCP 提供方](../../experimental/browser-use-playwright-mcp/README.zh.md) — Playwright 浏览器工具。
- [Chrome DevTools MCP 提供方](../../experimental/browser-use-chrome-devtools-mcp/README.zh.md) — Chromium 检查与控制。
- [Stagehand 提供方](../../experimental/browser-use-stagehand-native/README.zh.md) — 支持 AI（人工智能）辅助的原生浏览器操作。

-----

<a id="model-experience"></a>
## 模型体验

无，因为此注册表只记录 提供方 名称。

#### KV Cache 影响

注册不改变模型请求。提供方 拥有的工具与指导决定各自对请求前缀的影响。

## 已知限制与延期工作

<a id="known-limitations-and-deferred-work"></a>

服务在其 Cordis 服务实例内限制注册。

- **浏览器所有权** — 提供方 拥有浏览器资源并实施 Session 隔离；此服务不保存浏览器状态。
- **提供方 选择** — 配置选择 提供方；模型不能在运行时切换已注册后端。
- **执行覆盖范围** — 执行请求只作用于显式消费 API 的适配器，不拦截任意 shell/Python 脚本或 MCP 启动入口。resolver 身份检查及任务租约、context、下载资源清理由适配器拥有；声明能力不等于实现能力。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者工作上下文 — 点击展开</summary>

无。

</details>
