/** Explicit browser execution requests and adapter-resolved engine identities. */
import type { Branded } from '@deepseek-ai/dsh-brand';
/** Caller-owned identity of a browser execution Session or task batch. */
export type BrowserExecutionScopeId = Branded<'BrowserExecutionScopeId'>;
/** Resource owner and operation batch; taskId is not an Agent Teams task id. */
export interface BrowserExecutionScope {
    readonly sessionId: BrowserExecutionScopeId;
    readonly taskId: BrowserExecutionScopeId;
}
/** Window behavior requested independently of filesystem permissions. */
export type BrowserExecutionMode = 'headless' | 'headed' | 'native';
/** User operation determining the default window behavior. */
export type BrowserExecutionPurpose = 'automation' | 'capture' | 'web-regression' | 'interactive' | 'desktop-regression';
/** Operations that an execution adapter must support without changing mode. */
export type BrowserExecutionCapability = 'dom' | 'screenshot' | 'browser-extension' | 'native-window' | 'isolated-context' | 'isolated-download-directory' | 'authenticated-state';
/** Explicit request resolved before acquiring any browser resources. */
export interface BrowserExecutionRequest {
    readonly scope: BrowserExecutionScope;
    readonly purpose: BrowserExecutionPurpose;
    readonly mode?: BrowserExecutionMode;
    readonly ownership: 'owned-process' | 'borrowed-connection' | 'task-lease';
    /** Browser resource owner; required for task leases that do not own the browser process. */
    readonly resourceOwnerId?: BrowserExecutionScopeId;
    readonly capabilities: readonly BrowserExecutionCapability[];
}
/** Immutable operation-local request after purpose defaults are resolved. */
export interface BrowserExecutionSpec extends BrowserExecutionRequest {
    readonly mode: BrowserExecutionMode;
}
/** Engine identity supplied by the adapter's actual package/system resolver. */
export interface BrowserEngineIdentity {
    readonly kind: 'chromium-headless-shell' | 'chromium' | 'electron' | 'external-browser';
    /** Resolver implementation, not a caller-provided verification boolean. */
    readonly resolver: string;
    /** Actual canonical executable selected by the resolver, absent for attachment. */
    readonly executablePath?: string;
    readonly packageName?: string;
    readonly packageVersion?: string;
    readonly browserRevision?: string;
    /** Actual installed browser version reported by the adapter, not its package version. */
    readonly browserVersion?: string;
    readonly capabilities: readonly BrowserExecutionCapability[];
}
/** Final operation sent to the backend after resolving its engine. */
export type BrowserExecutionTarget = {
    readonly kind: 'launch';
    readonly engine: BrowserEngineIdentity;
    readonly options: {
        readonly executablePath: string;
        readonly headless: boolean;
        readonly channel?: string;
        readonly args: readonly string[];
    };
} | {
    readonly kind: 'attach';
    readonly engine: BrowserEngineIdentity;
    /** Actual owner recovered by the adapter's resource broker, required for task leases. */
    readonly resourceOwnerId?: BrowserExecutionScopeId;
} | {
    readonly kind: 'native';
    readonly engine: BrowserEngineIdentity;
    /** Actual persistent app owner recovered by its broker, required for task leases. */
    readonly resourceOwnerId?: BrowserExecutionScopeId;
};
/** Adapter-reviewed inventory for one installed Playwright shell; never operation/tool input. */
export interface HeadlessEnginePin {
    readonly packageName: 'playwright-core';
    readonly packageVersion: string;
    readonly browserName: 'chromium-headless-shell';
    readonly revision: string;
    readonly browserVersion: string;
    readonly platform: 'darwin';
    readonly arch: 'arm64';
    readonly minimumDarwinMajor: number;
    readonly directory: 'chrome-headless-shell-mac-arm64';
    readonly executable: 'chrome-headless-shell';
    /** Every required installation resource and actual binary, relative to the shell directory. */
    readonly files: Readonly<Record<string, string>>;
    /** Download/provenance notes belong to the adapter, not a proof of upstream signature. */
    readonly source?: string;
    readonly digestProvenance?: string;
}
/** Operation-local inputs; there are no injectable system/hash/version verification functions. */
export interface HeadlessEngineResolutionOptions {
    readonly pin: HeadlessEnginePin;
    /** Absolute package root chosen by the adapter, including a Python Playwright driver's package. */
    readonly playwrightPackageRoot: string;
    readonly overrideName: string;
    readonly env?: Readonly<Record<string, string | undefined>>;
    /** Absolute execution cwd; relative environment/cache paths never use INIT_CWD. */
    readonly cwd?: string;
    /** Explicit constructor executable takes precedence over the environment but receives all checks. */
    readonly executablePath?: string;
}
/** Actual filesystem/package/system/version evidence, suitable for final execution validation. */
export interface ResolvedHeadlessEngine extends BrowserEngineIdentity {
    readonly kind: 'chromium-headless-shell';
    readonly resolver: 'playwright-pinned-headless-shell';
    readonly executablePath: string;
    readonly packageName: 'playwright-core';
    readonly packageVersion: string;
    readonly browserRevision: string;
    readonly browserVersion: string;
    readonly binarySha256: string;
    readonly platform: 'darwin';
    readonly arch: 'arm64';
}
/** Stable policy failure codes; backend resolution and startup failures remain separate. */
export type BrowserExecutionErrorCode = 'INVALID_BROWSER_EXECUTION_REQUEST' | 'UNSUPPORTED_BROWSER_CAPABILITY' | 'BROWSER_MODE_MISMATCH' | 'BROWSER_ENGINE_MISMATCH' | 'BROWSER_OWNERSHIP_MISMATCH';
//# sourceMappingURL=types.d.ts.map