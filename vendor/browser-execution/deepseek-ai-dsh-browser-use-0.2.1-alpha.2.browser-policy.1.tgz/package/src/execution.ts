/** Operation-local browser mode resolution and final adapter-argument validation. */

import type {
  BrowserExecutionCapability, BrowserExecutionErrorCode, BrowserExecutionRequest, BrowserExecutionScope,
  BrowserExecutionScopeId, BrowserExecutionSpec, BrowserExecutionTarget,
} from './types.ts'

export type * from './types.ts'

/** Structured denial before browser resource acquisition or backend dispatch. */
export class BrowserExecutionError extends Error {
  /** Stable denial classification for adapter and tool diagnostics. */
  readonly code: BrowserExecutionErrorCode
  /** Exact request owner, absent when external JSON could not be decoded. */
  readonly scope: BrowserExecutionScope | undefined

  constructor(code: BrowserExecutionErrorCode, spec: BrowserExecutionSpec | undefined, message: string) {
    super(message)
    this.name = 'BrowserExecutionError'
    this.code = code
    this.scope = spec?.scope
  }
}

/**
 * Brand an execution identity supplied by its Session or task-batch owner.
 * @param value - process-local or wire-decoded owner identity.
 * @returns the unchanged identity with its execution scope brand.
 */
export function BrowserExecutionScopeId(value: string): BrowserExecutionScopeId {
  return value as BrowserExecutionScopeId
}

function invalid(field: string): never {
  throw new BrowserExecutionError('INVALID_BROWSER_EXECUTION_REQUEST', undefined, `Invalid browser execution request field: ${field}`)
}
function object(value: unknown, field: string): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return invalid(field)
  return value as Record<string, unknown>
}
function identity(value: unknown, field: string): BrowserExecutionScopeId {
  if (typeof value !== 'string' || value.trim().length === 0) return invalid(field)
  return BrowserExecutionScopeId(value)
}
function oneOf<T extends string>(value: unknown, choices: readonly T[], field: string): T {
  for (const choice of choices) if (value === choice) return choice
  return invalid(field)
}

/**
 * Decode untrusted JavaScript/CLI JSON before typed request resolution.
 * Unknown fields and values fail explicitly; this does not validate an engine descriptor.
 * @param value - externally supplied JSON request.
 * @returns the validated request with branded owner identities.
 * @throws BrowserExecutionError for missing or unsupported request fields.
 */
export function parseBrowserExecutionRequest(value: unknown): BrowserExecutionRequest {
  const input = object(value, 'request')
  const keys = ['scope', 'purpose', 'mode', 'ownership', 'resourceOwnerId', 'capabilities']
  for (const key of Object.keys(input)) if (!keys.includes(key)) invalid(key)
  const scope = object(input.scope, 'scope')
  for (const key of Object.keys(scope)) if (key !== 'sessionId' && key !== 'taskId') invalid(`scope.${key}`)
  if (!Array.isArray(input.capabilities)) return invalid('capabilities')
  const capabilities = input.capabilities.map((item: unknown) => oneOf(item, [
    'dom', 'screenshot', 'browser-extension', 'native-window',
    'isolated-context', 'isolated-download-directory', 'authenticated-state',
  ] as const, 'capabilities'))
  const ownership = oneOf(input.ownership, ['owned-process', 'borrowed-connection', 'task-lease'] as const, 'ownership')
  const resourceOwnerId = input.resourceOwnerId === undefined ? undefined : identity(input.resourceOwnerId, 'resourceOwnerId')
  if (ownership === 'task-lease' && resourceOwnerId === undefined) return invalid('resourceOwnerId')
  return Object.freeze({
    scope: Object.freeze({ sessionId: identity(scope.sessionId, 'scope.sessionId'), taskId: identity(scope.taskId, 'scope.taskId') }),
    purpose: oneOf(input.purpose, ['automation', 'capture', 'web-regression', 'interactive', 'desktop-regression'] as const, 'purpose'),
    ownership, capabilities: Object.freeze(capabilities),
    ...input.mode === undefined ? {} : { mode: oneOf(input.mode, ['headless', 'headed', 'native'] as const, 'mode') },
    ...resourceOwnerId === undefined ? {} : { resourceOwnerId },
  })
}

/**
 * Resolve purpose defaults and snapshot one request without storing global policy.
 * Automatic page work defaults to headless; interactive and desktop work stay visible.
 * @param request - explicit Session, task batch, ownership, purpose, and capabilities.
 * @returns an immutable operation-local specification, independent of file sandbox mode.
 */
export function resolveBrowserExecution(request: BrowserExecutionRequest): BrowserExecutionSpec {
  const mode = request.mode ?? (request.purpose === 'desktop-regression' ? 'native'
    : request.purpose === 'interactive' ? 'headed' : 'headless')
  return Object.freeze({
    ...request, mode,
    scope: Object.freeze({ ...request.scope }),
    capabilities: Object.freeze([...request.capabilities]),
  })
}

/**
 * Reject unsupported capability requests before package discovery or resource acquisition.
 * @param spec - resolved operation-local request.
 * @param supported - capabilities implemented by the selected adapter.
 * @throws BrowserExecutionError when the requested mode or capabilities are unavailable.
 */
export function validateBrowserCapabilities(spec: BrowserExecutionSpec, supported: readonly BrowserExecutionCapability[]): void {
  if (spec.mode === 'headless' && spec.capabilities.some(value => value === 'browser-extension' || value === 'native-window')) {
    throw new BrowserExecutionError('UNSUPPORTED_BROWSER_CAPABILITY', spec,
      'True headless execution does not support browser-extension or native-window; request headed/native explicitly instead of GUI fallback')
  }
  for (const capability of spec.capabilities) {
    if (!supported.includes(capability)) {
      throw new BrowserExecutionError('UNSUPPORTED_BROWSER_CAPABILITY', spec, `Browser adapter does not support ${capability}`)
    }
  }
}

/**
 * Reject mode, capability, ownership, and final launch-argument mismatches.
 * The adapter must independently verify installed package/version/binary identity;
 * this function compares that resolver's result, not arbitrary executable contents.
 * Call immediately before every actual launch or attachment, including direct callers.
 * @param spec - resolved operation-local request.
 * @param target - adapter-resolved engine and the exact final backend arguments.
 * @throws BrowserExecutionError when the backend cannot honor the request without fallback.
 */
export function validateBrowserExecution(spec: BrowserExecutionSpec, target: BrowserExecutionTarget): void {
  const deny = (code: BrowserExecutionErrorCode, message: string): never => {
    throw new BrowserExecutionError(code, spec, message)
  }
  validateBrowserCapabilities(spec, target.engine.capabilities)
  if ((target.kind === 'launch' && spec.ownership !== 'owned-process')
    || (target.kind === 'attach' && spec.ownership === 'owned-process')
    || (target.kind === 'native' && spec.ownership === 'borrowed-connection')) {
    deny('BROWSER_OWNERSHIP_MISMATCH', 'Launch requires owned-process; attachment requires borrowed-connection or task-lease; native requires owned-process or task-lease')
  }
  if (spec.ownership === 'task-lease') {
    if (spec.resourceOwnerId === undefined) {
      deny('BROWSER_OWNERSHIP_MISMATCH', 'A task-lease requires its browser resourceOwnerId and never owns the browser process')
    }
    if (target.kind === 'launch' || spec.resourceOwnerId !== target.resourceOwnerId) {
      deny('BROWSER_OWNERSHIP_MISMATCH', 'Task-lease resourceOwnerId differs from the adapter broker resource owner')
    }
  }
  if (target.kind === 'attach') {
    if (spec.mode !== 'headed' || target.engine.kind !== 'external-browser') {
      deny('BROWSER_MODE_MISMATCH', 'Browser attachment requires headed mode; it cannot guarantee headless or replace native desktop execution')
    }
    return
  }
  if (target.kind === 'native') {
    if (spec.mode !== 'native' || target.engine.kind !== 'electron') {
      deny('BROWSER_MODE_MISMATCH', 'Native desktop execution requires native mode and its native engine')
    }
    return
  }
  const { options, engine } = target
  if (options.executablePath !== engine.executablePath) {
    deny('BROWSER_ENGINE_MISMATCH', 'Final executablePath differs from the adapter-resolved browser engine')
  }
  if (spec.mode === 'native') {
    deny('BROWSER_MODE_MISMATCH', 'A browser launch cannot replace a native desktop execution')
  }
  if (spec.mode === 'headless') {
    if (!options.headless || engine.kind !== 'chromium-headless-shell' || options.channel !== undefined) {
      deny('BROWSER_ENGINE_MISMATCH', 'True headless execution requires the resolved chromium-headless-shell and no channel override')
    }
    if (options.args.some(arg => arg === '--no-headless'
      || (arg.startsWith('--headless') && !['--headless', '--headless=new', '--headless=true'].includes(arg)))) {
      deny('BROWSER_MODE_MISMATCH', 'Final browser arguments contradict true headless execution')
    }
    if (options.args.some(arg => /^--(?:load-extension|disable-extensions-except|enable-unsafe-extension-debugging)(?:=|$)/u.test(arg))) {
      deny('UNSUPPORTED_BROWSER_CAPABILITY', 'Final browser arguments require extensions unavailable in true headless execution')
    }
  } else if (options.headless || engine.kind !== 'chromium' || options.args.some(arg => /^--headless(?:=|$)/u.test(arg))) {
    deny('BROWSER_MODE_MISMATCH', 'Headed execution must retain its normal visible window')
  }
}
