/** Operation-local browser mode resolution and final adapter-argument validation. */
import type { BrowserExecutionCapability, BrowserExecutionErrorCode, BrowserExecutionRequest, BrowserExecutionScope, BrowserExecutionScopeId, BrowserExecutionSpec, BrowserExecutionTarget } from './types.ts';
export type * from './types.ts';
/** Structured denial before browser resource acquisition or backend dispatch. */
export declare class BrowserExecutionError extends Error {
    /** Stable denial classification for adapter and tool diagnostics. */
    readonly code: BrowserExecutionErrorCode;
    /** Exact request owner, absent when external JSON could not be decoded. */
    readonly scope: BrowserExecutionScope | undefined;
    constructor(code: BrowserExecutionErrorCode, spec: BrowserExecutionSpec | undefined, message: string);
}
/**
 * Brand an execution identity supplied by its Session or task-batch owner.
 * @param value - process-local or wire-decoded owner identity.
 * @returns the unchanged identity with its execution scope brand.
 */
export declare function BrowserExecutionScopeId(value: string): BrowserExecutionScopeId;
/**
 * Decode untrusted JavaScript/CLI JSON before typed request resolution.
 * Unknown fields and values fail explicitly; this does not validate an engine descriptor.
 * @param value - externally supplied JSON request.
 * @returns the validated request with branded owner identities.
 * @throws BrowserExecutionError for missing or unsupported request fields.
 */
export declare function parseBrowserExecutionRequest(value: unknown): BrowserExecutionRequest;
/**
 * Resolve purpose defaults and snapshot one request without storing global policy.
 * Automatic page work defaults to headless; interactive and desktop work stay visible.
 * @param request - explicit Session, task batch, ownership, purpose, and capabilities.
 * @returns an immutable operation-local specification, independent of file sandbox mode.
 */
export declare function resolveBrowserExecution(request: BrowserExecutionRequest): BrowserExecutionSpec;
/**
 * Reject unsupported capability requests before package discovery or resource acquisition.
 * @param spec - resolved operation-local request.
 * @param supported - capabilities implemented by the selected adapter.
 * @throws BrowserExecutionError when the requested mode or capabilities are unavailable.
 */
export declare function validateBrowserCapabilities(spec: BrowserExecutionSpec, supported: readonly BrowserExecutionCapability[]): void;
/**
 * Reject mode, capability, ownership, and final launch-argument mismatches.
 * The adapter must independently verify installed package/version/binary identity;
 * this function compares that resolver's result, not arbitrary executable contents.
 * Call immediately before every actual launch or attachment, including direct callers.
 * @param spec - resolved operation-local request.
 * @param target - adapter-resolved engine and the exact final backend arguments.
 * @throws BrowserExecutionError when the backend cannot honor the request without fallback.
 */
export declare function validateBrowserExecution(spec: BrowserExecutionSpec, target: BrowserExecutionTarget): void;
