/** Resolve an operation-local, pinned Playwright shell without GUI fallback. */
import type { HeadlessEngineResolutionOptions, ResolvedHeadlessEngine } from './types.ts';
export type { HeadlessEnginePin, HeadlessEngineResolutionOptions, ResolvedHeadlessEngine } from './types.ts';
/** A real installation/system check failed; no alternative browser was acquired. */
export declare class HeadlessEngineError extends Error {
    /** Stable resolver failure, separate from execution policy and backend launch errors. */
    readonly code = "HEADLESS_BROWSER_UNAVAILABLE";
    constructor(message: string, cause: unknown);
}
/**
 * Resolve and verify one exact pinned installation for the current operation.
 * The pin is trusted adapter configuration, not caller/tool JSON. System identity,
 * SHA-256 verification, and the version subprocess are real Node dependencies.
 * @param options - trusted pin/package root, operation environment/cwd, and optional explicit executable.
 * @returns immutable engine identity consumed by final browser execution validation.
 * @throws HeadlessEngineError for malformed inputs, unsupported systems, or any failed installation check.
 */
export declare function resolvePinnedHeadlessEngine(options: HeadlessEngineResolutionOptions): ResolvedHeadlessEngine;
